using Microsoft.EntityFrameworkCore;
using PizzaExpress.Data;

namespace PizzaExpress
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var MyAllowSpecificOrigins = "_myAllowSpecificOrigins";

            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddCors(options =>
            {
                options.AddPolicy(name: MyAllowSpecificOrigins, policy =>
                {
                    policy.WithOrigins("http://127.0.0.1:5500", "http://localhost:5500")
                          .AllowAnyMethod()
                          .AllowAnyHeader()
                          .AllowCredentials();
                });
            });


            builder.Services.AddControllers()
                .AddXmlSerializerFormatters();


            builder.Services.AddDbContext<PizzaContext>(opt =>
                opt.UseInMemoryDatabase("dbpizze"));


            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            using (var service = app.Services.CreateScope())
            {
                var ctx = service.ServiceProvider.GetRequiredService<PizzaContext>();
                SeedData.Initialize(ctx);
            }

      

            app.UseRouting();              
            app.UseCors(MyAllowSpecificOrigins);
            app.UseAuthorization();              
            app.MapControllers();              

      
            app.UseSwagger();
            app.UseSwaggerUI();

            app.Run();
        }
    }
}
