namespace PizzaExpress.Models
{
    public class Pizza
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
        public decimal Prezzo { get; set; }
    }
}