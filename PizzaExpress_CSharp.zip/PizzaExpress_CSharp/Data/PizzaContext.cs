using Microsoft.EntityFrameworkCore;
using PizzaExpress.Models;

namespace PizzaExpress.Data
{
    public class PizzaContext : DbContext
    {
        public PizzaContext(DbContextOptions<PizzaContext> options) : base(options) { }

        public DbSet<Pizza> Pizze => Set<Pizza>();
    }

    public static class SeedData
    {
        public static void Initialize(PizzaContext ctx)
        {
            if (ctx.Pizze.Any()) return;
            ctx.Pizze.AddRange(
                new Pizza { Id = 1, Nome = "Margherita", Prezzo = 4.50m },
                new Pizza { Id = 2, Nome = "Prosciutto", Prezzo = 5.50m },
                new Pizza { Id = 3, Nome = "Capricciosa", Prezzo = 7.00m }
            );
            ctx.SaveChanges();
        }
    }
}